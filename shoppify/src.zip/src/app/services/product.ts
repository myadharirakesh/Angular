export class product{
    productId:any;
    productName:any;
    productCompany:any;
    productPrice:any;
    productDescription:any;
    productImage:any;
}